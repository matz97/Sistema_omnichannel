import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import * as db from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Conversations Router
  conversations: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role === "admin") {
        // Gerentes veem todas as conversas
        return await db.getPendingConversations();
      } else {
        // Atendentes veem suas conversas
        const profile = await db.getUserProfile(ctx.user.id);
        if (profile?.userType === "attendant") {
          return await db.getConversationsByAttendantId(ctx.user.id);
        }
        // Pacientes veem suas conversas
        return await db.getConversationsByPatientId(ctx.user.id);
      }
    }),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input, ctx }) => {
        const conversation = await db.getConversationById(input.id);
        if (!conversation) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }
        // Verificar permissões
        if (ctx.user.role !== "admin" && 
            conversation.patientId !== ctx.user.id && 
            conversation.attendantId !== ctx.user.id) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return conversation;
      }),

    create: protectedProcedure
      .input(z.object({
        channelId: z.number(),
        subject: z.string().optional(),
        priority: z.enum(["low", "medium", "high"]).optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const profile = await db.getUserProfile(ctx.user.id);
        if (profile?.userType !== "patient") {
          throw new TRPCError({ code: "FORBIDDEN", message: "Only patients can create conversations" });
        }
        
        return await db.createConversation({
          patientId: ctx.user.id,
          channelId: input.channelId,
          subject: input.subject,
          priority: input.priority || "medium",
          status: "pending",
        });
      }),

    assignToAttendant: protectedProcedure
      .input(z.object({
        conversationId: z.number(),
        attendantId: z.number(),
      }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN", message: "Only managers can assign conversations" });
        }
        
        await db.assignConversationToAttendant(input.conversationId, input.attendantId);
        return { success: true };
      }),

    updateStatus: protectedProcedure
      .input(z.object({
        conversationId: z.number(),
        status: z.enum(["pending", "in_progress", "resolved", "closed"]),
      }))
      .mutation(async ({ input, ctx }) => {
        const conversation = await db.getConversationById(input.conversationId);
        if (!conversation) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }
        
        if (ctx.user.role !== "admin" && conversation.attendantId !== ctx.user.id) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        
        await db.updateConversationStatus(input.conversationId, input.status);
        return { success: true };
      }),

    getPending: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return await db.getPendingConversations();
    }),
  }),

  // Messages Router
  messages: router({
    list: protectedProcedure
      .input(z.object({ conversationId: z.number() }))
      .query(async ({ input, ctx }) => {
        const conversation = await db.getConversationById(input.conversationId);
        if (!conversation) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }
        
        if (ctx.user.role !== "admin" && 
            conversation.patientId !== ctx.user.id && 
            conversation.attendantId !== ctx.user.id) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        
        return await db.getMessagesByConversationId(input.conversationId);
      }),

    send: protectedProcedure
      .input(z.object({
        conversationId: z.number(),
        content: z.string().min(1),
        messageType: z.enum(["text", "image", "file", "system"]).optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const conversation = await db.getConversationById(input.conversationId);
        if (!conversation) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }
        
        if (ctx.user.role !== "admin" && 
            conversation.patientId !== ctx.user.id && 
            conversation.attendantId !== ctx.user.id) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        
        return await db.createMessage({
          conversationId: input.conversationId,
          senderId: ctx.user.id,
          content: input.content,
          messageType: input.messageType || "text",
        });
      }),

    markAsRead: protectedProcedure
      .input(z.object({ conversationId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const conversation = await db.getConversationById(input.conversationId);
        if (!conversation) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }
        
        await db.markMessagesAsRead(input.conversationId);
        return { success: true };
      }),
  }),

  // Channels Router
  channels: router({
    list: publicProcedure.query(async () => {
      return await db.getChannels();
    }),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await db.getChannelById(input.id);
      }),
  }),

  // Specialties Router
  specialties: router({
    list: publicProcedure.query(async () => {
      return await db.getSpecialties();
    }),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await db.getSpecialtyById(input.id);
      }),
  }),

  // Appointments Router
  appointments: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const profile = await db.getUserProfile(ctx.user.id);
      if (profile?.userType === "patient") {
        return await db.getAppointmentsByPatientId(ctx.user.id);
      }
      // Doctors and managers can see upcoming appointments
      return await db.getUpcomingAppointments();
    }),

    create: protectedProcedure
      .input(z.object({
        patientId: z.number(),
        doctorId: z.number(),
        specialtyId: z.number(),
        appointmentDate: z.date(),
        conversationId: z.number().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const profile = await db.getUserProfile(ctx.user.id);
        if (profile?.userType !== "attendant" && ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        
        return await db.createAppointment({
          patientId: input.patientId,
          doctorId: input.doctorId,
          specialtyId: input.specialtyId,
          appointmentDate: input.appointmentDate,
          conversationId: input.conversationId,
          notes: input.notes,
          status: "scheduled",
        });
      }),
  }),

  // Metrics Router
  metrics: router({
    getAttendantMetrics: protectedProcedure
      .input(z.object({ attendantId: z.number() }))
      .query(async ({ input, ctx }) => {
        if (ctx.user.role !== "admin" && ctx.user.id !== input.attendantId) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return await db.getAttendantMetrics(input.attendantId);
      }),

    getAllMetrics: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return await db.getAllAttendantMetrics();
    }),

    updateMetrics: protectedProcedure
      .input(z.object({
        attendantId: z.number(),
        totalAttendances: z.number().optional(),
        averageResponseTime: z.number().optional(),
        resolvedConversations: z.number().optional(),
        customerSatisfaction: z.number().optional(),
        appointmentsScheduled: z.number().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        
        const currentMetrics = await db.getAttendantMetrics(input.attendantId);
        
        return await db.updateAttendantMetrics({
          attendantId: input.attendantId,
          totalAttendances: input.totalAttendances ?? currentMetrics?.totalAttendances ?? 0,
          averageResponseTime: input.averageResponseTime ?? currentMetrics?.averageResponseTime ?? 0,
          resolvedConversations: input.resolvedConversations ?? currentMetrics?.resolvedConversations ?? 0,
          customerSatisfaction: input.customerSatisfaction ?? currentMetrics?.customerSatisfaction ?? 0,
          appointmentsScheduled: input.appointmentsScheduled ?? currentMetrics?.appointmentsScheduled ?? 0,
        });
      }),
  }),

  // Quick Replies Router
  quickReplies: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getQuickRepliesByAttendantId(ctx.user.id);
    }),

    create: protectedProcedure
      .input(z.object({
        title: z.string().min(1),
        content: z.string().min(1),
        category: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const profile = await db.getUserProfile(ctx.user.id);
        if (profile?.userType !== "attendant") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        
        return await db.createQuickReply({
          attendantId: ctx.user.id,
          title: input.title,
          content: input.content,
          category: input.category,
        });
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input, ctx }) => {
        await db.deleteQuickReply(input.id);
        return { success: true };
      }),
  }),

  // User Profiles Router
  userProfiles: router({
    getProfile: protectedProcedure.query(async ({ ctx }) => {
      return await db.getUserProfile(ctx.user.id);
    }),

    createProfile: protectedProcedure
      .input(z.object({
        userType: z.enum(["patient", "attendant", "doctor", "manager"]),
        phone: z.string().optional(),
        specialtyId: z.number().optional(),
        department: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const existingProfile = await db.getUserProfile(ctx.user.id);
        if (existingProfile) {
          throw new TRPCError({ code: "CONFLICT", message: "Profile already exists" });
        }
        
        return await db.createUserProfile({
          userId: ctx.user.id,
          userType: input.userType,
          phone: input.phone,
          specialtyId: input.specialtyId,
          department: input.department,
          isActive: 1,
        });
      }),
  }),
});

export type AppRouter = typeof appRouter;
