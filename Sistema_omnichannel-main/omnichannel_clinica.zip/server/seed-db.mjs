import { drizzle } from "drizzle-orm/mysql2";
import mysql from "mysql2/promise";
import * as schema from "../drizzle/schema.ts";

const DATABASE_URL = process.env.DATABASE_URL;

async function seed() {
  if (!DATABASE_URL) {
    console.error("DATABASE_URL is not set");
    process.exit(1);
  }

  console.log("Starting database seeding...");

  const connection = await mysql.createConnection(DATABASE_URL);
  const db = drizzle(connection);

  try {
    // Criar especialidades
    console.log("Creating specialties...");
    await db.insert(schema.specialties).values([
      { name: "Cardiologia", description: "Especialidade em doenças do coração" },
      { name: "Dermatologia", description: "Especialidade em doenças da pele" },
      { name: "Oftalmologia", description: "Especialidade em doenças dos olhos" },
      { name: "Clínica Geral", description: "Atendimento geral de pacientes" },
      { name: "Pediatria", description: "Especialidade em saúde infantil" },
    ]);

    // Criar canais
    console.log("Creating channels...");
    await db.insert(schema.channels).values([
      { type: "whatsapp", name: "WhatsApp", isActive: 1 },
      { type: "messenger", name: "Facebook Messenger", isActive: 1 },
      { type: "instagram", name: "Instagram Direct", isActive: 1 },
      { type: "email", name: "Email", isActive: 1 },
      { type: "chat", name: "Chat do Site", isActive: 1 },
    ]);

    console.log("Database seeding completed successfully!");
  } catch (error) {
    console.error("Error seeding database:", error);
    process.exit(1);
  } finally {
    await connection.end();
  }
}

seed();
