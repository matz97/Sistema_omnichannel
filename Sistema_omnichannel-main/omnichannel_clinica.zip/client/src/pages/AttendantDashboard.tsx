import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { MessageSquare, Send, LogOut, Clock } from "lucide-react";

export default function AttendantDashboard() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [selectedConversation, setSelectedConversation] = useState<number | null>(null);
  const [messageContent, setMessageContent] = useState("");

  const { data: conversations, isLoading: conversationsLoading } = trpc.conversations.list.useQuery();
  const { data: messages } = trpc.messages.list.useQuery(
    { conversationId: selectedConversation || 0 },
    { enabled: !!selectedConversation }
  );

  const sendMessageMutation = trpc.messages.send.useMutation({
    onSuccess: () => {
      setMessageContent("");
    },
  });

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedConversation || !messageContent.trim()) return;

    await sendMessageMutation.mutateAsync({
      conversationId: selectedConversation,
      content: messageContent,
      messageType: "text",
    });
  };

  const handleLogout = async () => {
    await logout();
    setLocation("/");
  };

  if (!user) {
    return <div className="flex items-center justify-center min-h-screen">Carregando...</div>;
  }

  const selectedConv = conversations?.find((c) => c.id === selectedConversation);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Painel do Atendente</h1>
            <p className="text-sm text-gray-600">{user.name}</p>
          </div>
          <Button variant="outline" onClick={handleLogout}>
            <LogOut className="mr-2 h-4 w-4" />
            Sair
          </Button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-[calc(100vh-200px)]">
          {/* Lista de Conversas */}
          <div className="lg:col-span-1 overflow-hidden flex flex-col">
            <Card className="flex-1 flex flex-col">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center text-lg">
                  <MessageSquare className="mr-2 h-5 w-5" />
                  Conversas
                </CardTitle>
                <CardDescription>
                  {conversations?.length || 0} conversas
                </CardDescription>
              </CardHeader>
              <CardContent className="flex-1 overflow-y-auto">
                <div className="space-y-2">
                  {conversationsLoading ? (
                    <p className="text-gray-500 text-sm">Carregando...</p>
                  ) : conversations && conversations.length > 0 ? (
                    conversations.map((conversation) => (
                      <div
                        key={conversation.id}
                        onClick={() => setSelectedConversation(conversation.id)}
                        className={`p-3 rounded-lg cursor-pointer transition ${
                          selectedConversation === conversation.id
                            ? "bg-blue-100 border-l-4 border-blue-600"
                            : "bg-gray-100 hover:bg-gray-200"
                        }`}
                      >
                        <p className="font-medium text-sm text-gray-900 truncate">
                          {conversation.subject || "Sem assunto"}
                        </p>
                        <p className="text-xs text-gray-600 mt-1">
                          Paciente ID: {conversation.patientId}
                        </p>
                        <div className="flex items-center mt-2">
                          <span className={`px-2 py-0.5 rounded text-xs font-medium ${
                            conversation.status === "resolved" ? "bg-green-200 text-green-800" :
                            conversation.status === "in_progress" ? "bg-blue-200 text-blue-800" :
                            "bg-yellow-200 text-yellow-800"
                          }`}>
                            {conversation.status}
                          </span>
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-gray-500 text-sm text-center py-8">Nenhuma conversa</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Detalhes da Conversa */}
          <div className="lg:col-span-3 overflow-hidden flex flex-col">
            {selectedConversation && selectedConv ? (
              <Card className="flex-1 flex flex-col">
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle>{selectedConv.subject || "Conversa"}</CardTitle>
                      <CardDescription>
                        Status: {selectedConv.status} • Prioridade: {selectedConv.priority}
                      </CardDescription>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          // Marcar como resolvido
                        }}
                      >
                        Resolver
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="flex-1 flex flex-col overflow-hidden">
                  {/* Mensagens */}
                  <div className="flex-1 overflow-y-auto mb-4 space-y-3 bg-gray-50 p-4 rounded-lg">
                    {messages && messages.length > 0 ? (
                      messages.map((message) => (
                        <div
                          key={message.id}
                          className={`flex ${message.senderId === user.id ? "justify-end" : "justify-start"}`}
                        >
                          <div
                            className={`max-w-xs px-4 py-2 rounded-lg ${
                              message.senderId === user.id
                                ? "bg-blue-600 text-white"
                                : "bg-white text-gray-900 border border-gray-200"
                            }`}
                          >
                            <p className="text-sm">{message.content}</p>
                            <p className={`text-xs mt-1 ${
                              message.senderId === user.id ? "text-blue-100" : "text-gray-500"
                            }`}>
                              {new Date(message.createdAt).toLocaleTimeString("pt-BR")}
                            </p>
                          </div>
                        </div>
                      ))
                    ) : (
                      <p className="text-gray-500 text-center py-8">Nenhuma mensagem ainda</p>
                    )}
                  </div>

                  {/* Input de Mensagem */}
                  <form onSubmit={handleSendMessage} className="flex gap-2">
                    <input
                      type="text"
                      value={messageContent}
                      onChange={(e) => setMessageContent(e.target.value)}
                      placeholder="Digite sua mensagem..."
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    <Button
                      type="submit"
                      disabled={!messageContent.trim()}
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      <Send className="h-4 w-4" />
                    </Button>
                  </form>
                </CardContent>
              </Card>
            ) : (
              <Card className="flex items-center justify-center">
                <div className="text-center py-12">
                  <Clock className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">Selecione uma conversa para começar</p>
                </div>
              </Card>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
