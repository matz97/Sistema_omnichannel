import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useState, useMemo } from "react";
import { BarChart3, Users, TrendingUp, LogOut, AlertCircle } from "lucide-react";
import { PerformanceChart } from "@/components/PerformanceChart";

export default function ManagerDashboard() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [selectedConversation, setSelectedConversation] = useState<number | null>(null);

  const { data: conversations } = trpc.conversations.list.useQuery();
  const { data: pendingConversations } = trpc.conversations.getPending.useQuery();
  const { data: allMetrics } = trpc.metrics.getAllMetrics.useQuery();

  const handleLogout = async () => {
    await logout();
    setLocation("/");
  };

  if (!user) {
    return <div className="flex items-center justify-center min-h-screen">Carregando...</div>;
  }

  const totalConversations = conversations?.length || 0;
  const pendingCount = pendingConversations?.length || 0;
  const resolvedCount = conversations?.filter((c) => c.status === "resolved").length || 0;
  const averageSatisfaction = allMetrics && allMetrics.length > 0
    ? Math.round(allMetrics.reduce((sum, m) => sum + m.customerSatisfaction, 0) / allMetrics.length)
    : 0;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Painel do Gerente</h1>
            <p className="text-sm text-gray-600">Supervisão e Métricas de Desempenho</p>
          </div>
          <Button variant="outline" onClick={handleLogout}>
            <LogOut className="mr-2 h-4 w-4" />
            Sair
          </Button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* KPIs */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Total de Conversas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-gray-900">{totalConversations}</div>
              <p className="text-xs text-gray-500 mt-1">Todas as conversas</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
                <AlertCircle className="h-4 w-4 mr-2 text-red-500" />
                Pendentes
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-red-600">{pendingCount}</div>
              <p className="text-xs text-gray-500 mt-1">Aguardando atendente</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
                <TrendingUp className="h-4 w-4 mr-2 text-green-500" />
                Resolvidas
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-600">{resolvedCount}</div>
              <p className="text-xs text-gray-500 mt-1">Taxa de resolução</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">Satisfação Média</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-600">{averageSatisfaction}%</div>
              <p className="text-xs text-gray-500 mt-1">Satisfação dos pacientes</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Conversas Pendentes */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <AlertCircle className="mr-2 h-5 w-5 text-red-500" />
                  Conversas Pendentes
                </CardTitle>
                <CardDescription>Conversas aguardando atribuição a atendente</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {pendingConversations && pendingConversations.length > 0 ? (
                    pendingConversations.map((conversation) => (
                      <div
                        key={conversation.id}
                        onClick={() => setSelectedConversation(conversation.id)}
                        className="p-4 border border-red-200 bg-red-50 rounded-lg hover:bg-red-100 cursor-pointer transition"
                      >
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <p className="font-medium text-gray-900">
                              {conversation.subject || "Conversa sem assunto"}
                            </p>
                            <p className="text-sm text-gray-600 mt-1">
                              Paciente ID: {conversation.patientId}
                            </p>
                            <p className="text-xs text-gray-500 mt-1">
                              {new Date(conversation.createdAt).toLocaleDateString("pt-BR", {
                                month: "short",
                                day: "numeric",
                                hour: "2-digit",
                                minute: "2-digit",
                              })}
                            </p>
                          </div>
                          <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                            conversation.priority === "high" ? "bg-red-200 text-red-800" :
                            conversation.priority === "medium" ? "bg-yellow-200 text-yellow-800" :
                            "bg-green-200 text-green-800"
                          }`}>
                            {conversation.priority}
                          </span>
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-gray-500 text-center py-8">Nenhuma conversa pendente</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Métricas de Atendentes */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Users className="mr-2 h-5 w-5" />
                  Desempenho dos Atendentes
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {allMetrics && allMetrics.length > 0 ? (
                    allMetrics.slice(0, 5).map((metric) => (
                      <div key={metric.id} className="p-3 bg-gray-50 rounded-lg">
                        <p className="font-medium text-sm text-gray-900">
                          Atendente #{metric.attendantId}
                        </p>
                        <div className="mt-2 space-y-1 text-xs text-gray-600">
                          <p>Atendimentos: {metric.totalAttendances}</p>
                          <p>Resolvidas: {metric.resolvedConversations}</p>
                          <p>Satisfação: {metric.customerSatisfaction}%</p>
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-gray-500 text-sm text-center py-8">Sem métricas disponíveis</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Gráfico de Status */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="flex items-center">
              <BarChart3 className="mr-2 h-5 w-5" />
              Distribuição de Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { label: "Pendentes", value: pendingCount, color: "bg-yellow-100 text-yellow-800" },
                { label: "Em Progresso", value: conversations?.filter((c) => c.status === "in_progress").length || 0, color: "bg-blue-100 text-blue-800" },
                { label: "Resolvidas", value: resolvedCount, color: "bg-green-100 text-green-800" },
                { label: "Fechadas", value: conversations?.filter((c) => c.status === "closed").length || 0, color: "bg-gray-100 text-gray-800" },
              ].map((item) => (
                <div key={item.label} className={`p-4 rounded-lg ${item.color}`}>
                  <p className="text-sm font-medium">{item.label}</p>
                  <p className="text-2xl font-bold mt-2">{item.value}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Grafico de Desempenho */}
        {allMetrics && allMetrics.length > 0 && (
          <div className="mt-6">
            <PerformanceChart
              data={allMetrics.map((metric) => ({
                name: `Atendente #${metric.attendantId}`,
                atendimentos: metric.totalAttendances,
                resolvidas: metric.resolvedConversations,
                satisfacao: metric.customerSatisfaction,
              }))}
              title="Desempenho dos Atendentes"
              description="Comparacao de metricas entre atendentes"
            />
          </div>
        )}
      </main>
    </div>
  );
}
