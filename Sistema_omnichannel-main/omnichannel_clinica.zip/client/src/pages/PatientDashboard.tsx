import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { MessageCircle, Calendar, LogOut, Plus } from "lucide-react";
import { ChannelIcon, getChannelColor, getChannelName } from "@/components/ChannelIcon";

export default function PatientDashboard() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [showNewConversation, setShowNewConversation] = useState(false);
  const [selectedChannel, setSelectedChannel] = useState<number | null>(null);
  const [subject, setSubject] = useState("");

  const { data: conversations, isLoading: conversationsLoading } = trpc.conversations.list.useQuery();
  const { data: channels } = trpc.channels.list.useQuery();
  const { data: appointments } = trpc.appointments.list.useQuery();

  const createConversationMutation = trpc.conversations.create.useMutation({
    onSuccess: () => {
      setShowNewConversation(false);
      setSelectedChannel(null);
      setSubject("");
    },
  });

  const handleCreateConversation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedChannel) return;

    await createConversationMutation.mutateAsync({
      channelId: selectedChannel,
      subject: subject || undefined,
    });
  };

  const handleLogout = async () => {
    await logout();
    setLocation("/");
  };

  if (!user) {
    return <div className="flex items-center justify-center min-h-screen">Carregando...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Meu Atendimento</h1>
            <p className="text-sm text-gray-600">Bem-vindo, {user.name}</p>
          </div>
          <Button variant="outline" onClick={handleLogout}>
            <LogOut className="mr-2 h-4 w-4" />
            Sair
          </Button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Conversas */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Minhas Conversas</CardTitle>
                  <CardDescription>Histórico de comunicações com a clínica</CardDescription>
                </div>
                <Button
                  size="sm"
                  onClick={() => setShowNewConversation(!showNewConversation)}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Nova Conversa
                </Button>
              </CardHeader>
              <CardContent>
                {showNewConversation && (
                  <form onSubmit={handleCreateConversation} className="mb-6 p-4 bg-blue-50 rounded-lg">
                    <div className="space-y-4">
                      <div>
                        <label className="text-sm font-medium">Canal de Comunicação</label>
                        <select
                          value={selectedChannel || ""}
                          onChange={(e) => setSelectedChannel(Number(e.target.value))}
                          className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        >
                          <option value="">Selecione um canal</option>
                          {channels?.map((channel) => (
                            <option key={channel.id} value={channel.id}>
                              {channel.name}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="text-sm font-medium">Assunto (opcional)</label>
                        <input
                          type="text"
                          value={subject}
                          onChange={(e) => setSubject(e.target.value)}
                          placeholder="Ex: Agendamento de consulta"
                          className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                      <div className="flex gap-2">
                        <Button
                          type="submit"
                          disabled={!selectedChannel}
                          className="bg-blue-600 hover:bg-blue-700"
                        >
                          Iniciar Conversa
                        </Button>
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => setShowNewConversation(false)}
                        >
                          Cancelar
                        </Button>
                      </div>
                    </div>
                  </form>
                )}

                <div className="space-y-3">
                  {conversationsLoading ? (
                    <p className="text-gray-500">Carregando conversas...</p>
                  ) : conversations && conversations.length > 0 ? (
                    conversations.map((conversation) => (
                      <div
                        key={conversation.id}
                        onClick={() => setLocation(`/conversation/${conversation.id}`)}
                        className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer transition"
                      >
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-2">
                                <ChannelIcon type={channels?.find(c => c.id === conversation.channelId)?.type as any} size="sm" />
                                <p className="font-medium text-gray-900">
                                  {conversation.subject || "Conversa sem assunto"}
                                </p>
                              </div>
                              <p className="text-sm text-gray-600">
                                Status: {conversation.status}
                              </p>
                              <p className="text-xs text-gray-500 mt-1">
                                {new Date(conversation.createdAt).toLocaleDateString("pt-BR")}
                              </p>
                            </div>
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            conversation.status === "resolved" ? "bg-green-100 text-green-800" :
                            conversation.status === "in_progress" ? "bg-blue-100 text-blue-800" :
                            "bg-yellow-100 text-yellow-800"
                          }`}>
                            {conversation.status}
                          </span>
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-gray-500 text-center py-8">Nenhuma conversa ainda</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Próximas Consultas */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Calendar className="mr-2 h-5 w-5" />
                  Próximas Consultas
                </CardTitle>
              </CardHeader>
              <CardContent>
                {appointments && appointments.length > 0 ? (
                  <div className="space-y-3">
                    {appointments.slice(0, 3).map((appointment) => (
                      <div key={appointment.id} className="p-3 bg-blue-50 rounded-lg">
                        <p className="font-medium text-sm text-gray-900">
                          {new Date(appointment.appointmentDate).toLocaleDateString("pt-BR", {
                            weekday: "short",
                            month: "short",
                            day: "numeric",
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </p>
                        <p className="text-xs text-gray-600 mt-1">
                          Status: {appointment.status}
                        </p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-500 text-sm">Nenhuma consulta agendada</p>
                )}
              </CardContent>
            </Card>

            {/* Canais Disponíveis */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <MessageCircle className="mr-2 h-5 w-5" />
                  Canais Disponíveis
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {channels?.map((channel) => (
                    <div key={channel.id} className="flex items-center p-2 bg-gray-50 rounded">
                      <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                      <span className="text-sm text-gray-700">{channel.name}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
