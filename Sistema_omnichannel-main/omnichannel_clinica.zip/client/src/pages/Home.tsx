import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { getLoginUrl } from "@/const";
import { MessageCircle, Users, BarChart3, Stethoscope } from "lucide-react";

export default function Home() {
  const { user, isAuthenticated, loading } = useAuth();
  const [, setLocation] = useLocation();

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando...</p>
        </div>
      </div>
    );
  }

  if (isAuthenticated && user) {
    // Redirecionar para página de configuração de perfil se não tiver perfil
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        {/* Header */}
        <header className="bg-white shadow">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
            <div className="flex items-center gap-3">
              <Stethoscope className="h-8 w-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-900">Clínica Omnichannel</h1>
            </div>
            <div className="text-sm text-gray-600">
              Bem-vindo, {user.name}
            </div>
          </div>
        </header>

        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Escolha seu Painel de Acesso
            </h2>
            <p className="text-lg text-gray-600">
              Selecione o tipo de usuário para acessar as funcionalidades apropriadas
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Painel do Paciente */}
            <Card className="hover:shadow-lg transition cursor-pointer" onClick={() => setLocation("/patient")}>
              <CardHeader>
                <div className="flex items-center justify-center w-12 h-12 bg-blue-100 rounded-lg mb-4">
                  <MessageCircle className="h-6 w-6 text-blue-600" />
                </div>
                <CardTitle>Painel do Paciente</CardTitle>
                <CardDescription>Envie mensagens e agende consultas</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-4">
                  Comunique-se com a clínica através de múltiplos canais e acompanhe suas consultas.
                </p>
                <Button className="w-full bg-blue-600 hover:bg-blue-700">
                  Acessar
                </Button>
              </CardContent>
            </Card>

            {/* Painel do Atendente */}
            <Card className="hover:shadow-lg transition cursor-pointer" onClick={() => setLocation("/attendant")}>
              <CardHeader>
                <div className="flex items-center justify-center w-12 h-12 bg-green-100 rounded-lg mb-4">
                  <Users className="h-6 w-6 text-green-600" />
                </div>
                <CardTitle>Painel do Atendente</CardTitle>
                <CardDescription>Gerencie conversas com pacientes</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-4">
                  Responda mensagens de pacientes em uma única plataforma unificada.
                </p>
                <Button className="w-full bg-green-600 hover:bg-green-700">
                  Acessar
                </Button>
              </CardContent>
            </Card>

            {/* Painel do Gerente */}
            <Card className="hover:shadow-lg transition cursor-pointer" onClick={() => setLocation("/manager")}>
              <CardHeader>
                <div className="flex items-center justify-center w-12 h-12 bg-purple-100 rounded-lg mb-4">
                  <BarChart3 className="h-6 w-6 text-purple-600" />
                </div>
                <CardTitle>Painel do Gerente</CardTitle>
                <CardDescription>Monitore desempenho da equipe</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-4">
                  Visualize métricas, gerencie filas e supervisione atendentes em tempo real.
                </p>
                <Button className="w-full bg-purple-600 hover:bg-purple-700">
                  Acessar
                </Button>
              </CardContent>
            </Card>

            {/* Configurar Perfil */}
            <Card className="hover:shadow-lg transition cursor-pointer" onClick={() => setLocation("/profile-setup")}>
              <CardHeader>
                <div className="flex items-center justify-center w-12 h-12 bg-orange-100 rounded-lg mb-4">
                  <Stethoscope className="h-6 w-6 text-orange-600" />
                </div>
                <CardTitle>Configurar Perfil</CardTitle>
                <CardDescription>Defina seu tipo de usuário</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-4">
                  Configure seu perfil e escolha seu tipo de usuário no sistema.
                </p>
                <Button className="w-full bg-orange-600 hover:bg-orange-700">
                  Configurar
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Informações sobre o Sistema */}
          <Card className="mt-12 bg-white">
            <CardHeader>
              <CardTitle>Sobre o Sistema Omnichannel</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">Múltiplos Canais</h3>
                  <p className="text-sm text-gray-600">
                    Comunique-se através de WhatsApp, Email, Chat, Messenger e Instagram em uma única plataforma.
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">Gestão Centralizada</h3>
                  <p className="text-sm text-gray-600">
                    Todos os atendimentos em um único lugar, facilitando o acompanhamento e a organização.
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">Relatórios e Métricas</h3>
                  <p className="text-sm text-gray-600">
                    Acompanhe o desempenho da equipe com métricas detalhadas e relatórios consolidados.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    );
  }

  // Página de login
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 to-indigo-700 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Stethoscope className="h-8 w-8 text-blue-600" />
            <h1 className="text-2xl font-bold text-gray-900">Clínica Omnichannel</h1>
          </div>
          <CardTitle>Sistema de Atendimento Unificado</CardTitle>
          <CardDescription>
            Gerencie todos os seus atendimentos em um único lugar
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-gray-600 mb-6 text-center">
            Faça login para acessar o sistema de atendimento omnichannel da clínica.
          </p>
          <a href={getLoginUrl()}>
            <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">
              Fazer Login
            </Button>
          </a>
        </CardContent>
      </Card>
    </div>
  );
}
